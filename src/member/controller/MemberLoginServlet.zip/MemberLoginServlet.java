package member.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import member.model.service.MemberService;
import member.model.vo.Admin;
import member.model.vo.Member;

/**
 * Servlet implementation class MemberLoginServlet
 */
@WebServlet("/login")
public class MemberLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MemberLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1.
		request.setCharacterEncoding("utf-8");
		//2.
		String userId = request.getParameter("email");
		String password = request.getParameter("password");
		//3.
		int result = new MemberService().searchAdmin(userId);
		if(result == 1) {
			Admin admin = new MemberService().loginAdmin(userId,password);
			response.setContentType("text/html; charset=utf-8"); 
			if(admin != null) {
				HttpSession session = request.getSession();
				session.setAttribute("admin", admin);
				response.sendRedirect("/math/views/main/adminmain.jsp");
			}else {
				RequestDispatcher view = request.getRequestDispatcher("/views/member/memberError.jsp");
				request.setAttribute("message", "로그인실패!");
				view.forward(request, response);
			}
		}else if(result == 0) {
			Member member = new MemberService().loginMember(userId,password);
			response.setContentType("text/html; charset=utf-8"); 
			if(member != null) {
				HttpSession session = request.getSession();
				session.setAttribute("member", member);
				response.sendRedirect("/math/memberView.jsp");
			}else {
				RequestDispatcher view = request.getRequestDispatcher("/views/member/memberError.jsp");
				request.setAttribute("message", "ID 와 PASSWORD 를 확인해주세요");
				view.forward(request, response);
			}
		}	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
